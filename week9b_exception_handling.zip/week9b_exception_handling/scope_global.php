<?php 
$a=5;

function test()
{
echo "Value of variable a is:$a";
}
test();
echo "Value of variable a outside the function is: $a";


?>